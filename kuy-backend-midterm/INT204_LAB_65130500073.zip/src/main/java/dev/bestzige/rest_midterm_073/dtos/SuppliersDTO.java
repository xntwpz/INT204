// Watchara Santawee (65130500073)
package dev.bestzige.rest_midterm_073.dtos;

import lombok.Data;

@Data
public class SuppliersDTO {
    private Integer id;
    private String companyName;
    private String contactName;
    private String phone;
}
