package dev.bestzige.rest_midterm_073;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestMidterm073ApplicationTests {

    @Test
    void contextLoads() {
    }

}
